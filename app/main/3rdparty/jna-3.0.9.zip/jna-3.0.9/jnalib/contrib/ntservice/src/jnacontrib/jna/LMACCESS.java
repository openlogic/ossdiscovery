/*
 * LMACCESS.java
 *
 * Created on 7. August 2007, 12:42
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package jnacontrib.jna;


/**
 *
 * @author TB
 */
public interface LMACCESS {
  public final static int FILTER_NORMAL_ACCOUNT = 2;
}
