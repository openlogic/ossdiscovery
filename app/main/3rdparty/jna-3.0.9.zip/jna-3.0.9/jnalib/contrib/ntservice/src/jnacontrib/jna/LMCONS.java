/*
 * LMCONS.java
 *
 * Created on 7. August 2007, 08:46
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package jnacontrib.jna;


/**
 *
 * @author TB
 */
public interface LMCONS {
  public final static int MAX_PREFERRED_LENGTH = -1;
}
